<?php

return [
    "all_time"                         => "",
    "apply"                            => "",
    "cancel"                           => "",
    "custom"                           => "",
    "from"                             => "",
    "last_30"                          => "",
    "last_7"                           => "",
    "last_financial_year"              => "",
    "last_month"                       => "",
    "last_year"                        => "",
    "same_month_last_year"             => "",
    "same_month_to_same_day_last_year" => "",
    "this_financial_year"              => "",
    "this_month"                       => "",
    "this_year"                        => "",
    "to"                               => "",
    "today"                            => "",
    "today_last_year"                  => "",
    "weekstart"                        => "",
    "yesterday"                        => "",
];
