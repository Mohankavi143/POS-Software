<?php

return [
    "category_name_required"            => "",
    "add_item"                          => "",
    "cannot_be_deleted"                 => "",
    "category_id"                       => "",
    "confirm_delete"                    => "",
    "confirm_restore"                   => "",
    "description"                       => "",
    "error_adding_updating"             => "",
    "info"                              => "",
    "name"                              => "",
    "new"                               => "",
    "no_expenses_categories_to_display" => "",
    "none_selected"                     => "",
    "one_or_multiple"                   => "",
    "quantity"                          => "",
    "successful_adding"                 => "",
    "successful_deleted"                => "",
    "successful_updating"               => "",
    "update"                            => "",
];
