<?php

return [
    "all"                  => "Vše",
    "columns"              => "Sloupce",
    "hide_show_pagination" => "Zobrazit/skrýt stránkování",
    "loading"              => "Nahrávám, prosím počkejte...",
    "page_from_to"         => "Zobrazeno {0} až {1} z {2} řádků",
    "refresh"              => "Obnovit",
    "rows_per_page"        => "{0} řádků na stránku",
    "toggle"               => "Přepnout",
];
