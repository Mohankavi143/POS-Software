<?php

return [
    "gcaptcha"                      => "",
    "go"                            => "",
    "invalid_gcaptcha"              => "",
    "invalid_installation"          => "",
    "invalid_username_and_password" => "",
    "login"                         => "",
    "logout"                        => "",
    "migration_needed"              => "",
    "password"                      => "",
    "required_username"             => "",
    "username"                      => "",
    "welcome"                       => "",
];
