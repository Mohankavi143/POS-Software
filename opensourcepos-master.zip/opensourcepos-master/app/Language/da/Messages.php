<?php

return [
    "first_name"            => "",
    "last_name"             => "",
    "message"               => "",
    "message_placeholder"   => "",
    "message_required"      => "",
    "multiple_phones"       => "",
    "phone"                 => "",
    "phone_number_required" => "",
    "phone_placeholder"     => "",
    "sms_send"              => "",
    "successfully_sent"     => "",
    "unsuccessfully_sent"   => "",
];
