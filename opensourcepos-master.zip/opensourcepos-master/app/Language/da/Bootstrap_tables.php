<?php

return [
    "all"                  => "Alle",
    "columns"              => "Kolonner",
    "hide_show_pagination" => "Gem/Vis sideinddeling",
    "loading"              => "Indlæser, vent venligst...",
    "page_from_to"         => "Viser {0} to {1} af {2} rækker",
    "refresh"              => "Opdater",
    "rows_per_page"        => "{0} rækker per side",
    "toggle"               => "Skift",
];
