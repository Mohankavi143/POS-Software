<?php

return [
    "no_permission_module" => "sizin icazəniz yoxdur",
    "unknown"              => "naməlum",
];
