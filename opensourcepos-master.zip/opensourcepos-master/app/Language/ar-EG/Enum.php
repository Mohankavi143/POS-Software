<?php

return [
    "half_down"  => "تقريب نصفي",
    "half_even"  => "نصف مزدوج",
    "half_five"  => "نصف الخمس",
    "half_odd"   => "نصف فردي",
    "half_up"    => "تقريب نصفي",
    "round_down" => "التقريب",
    "round_up"   => "التقريب",
];
