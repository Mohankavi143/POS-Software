<?php

return [
    "first_name"            => "الإسم الأول",
    "last_name"             => "الأسم الأخير",
    "message"               => "الرسالة",
    "message_placeholder"   => "رسالتك هنا...",
    "message_required"      => "الرسالة مطلوبة",
    "multiple_phones"       => "فى حالة إرسال الرسالة لأكثر من شخص قم بفصل الأرقام بعلامة الفاصلة",
    "phone"                 => "رقم المحمول",
    "phone_number_required" => "رقم المحمول مطلوب",
    "phone_placeholder"     => "رقم/أرقام المحمول هنا...",
    "sms_send"              => "إرسال SMS",
    "successfully_sent"     => "تم إرسال الرسالة بنجاح إلى: ",
    "unsuccessfully_sent"   => "لم يتم إرسال الرسالة بنجاح إلى: ",
];
