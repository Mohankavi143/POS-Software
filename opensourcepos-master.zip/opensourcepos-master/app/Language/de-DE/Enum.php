<?php

return [
    "half_down"  => "Halbe abrunden",
    "half_even"  => "Halbe symmetrisch gerade runden",
    "half_five"  => "",
    "half_odd"   => "Halbe symmetrisch ungerade runden",
    "half_up"    => "Halbe aufrunden",
    "round_down" => "Abrunden",
    "round_up"   => "Aufrunden",
];
