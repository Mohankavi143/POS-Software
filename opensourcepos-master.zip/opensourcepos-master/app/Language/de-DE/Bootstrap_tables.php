<?php

return [
    "all"                  => "Alle",
    "columns"              => "Spalten",
    "hide_show_pagination" => "Seitenzahlen anzeigen/verbergen",
    "loading"              => "Lade, bitte warten...",
    "page_from_to"         => "Zeige {0} bis {1} von {2} Zeile(n)",
    "refresh"              => "Aktualisieren",
    "rows_per_page"        => "{0} Einträge pro Seite",
    "toggle"               => "Umschalten",
];
