<?php

return [
    "all_time"                         => "Von Beginn weg",
    "apply"                            => "Apply",
    "cancel"                           => "Cancel",
    "custom"                           => "Custom",
    "from"                             => "From",
    "last_30"                          => "Letzte 30 Tage",
    "last_7"                           => "Letzte 7 Tage",
    "last_financial_year"              => "",
    "last_month"                       => "Letzter Monat",
    "last_year"                        => "Letztes Jahr",
    "same_month_last_year"             => "Dieser Monat letzten Jahres",
    "same_month_to_same_day_last_year" => "Dieser Monat bis Heute letzten Jahres",
    "this_financial_year"              => "",
    "this_month"                       => "Dieser Monat",
    "this_year"                        => "Dieses Jahr",
    "to"                               => "To",
    "today"                            => "Heute",
    "today_last_year"                  => "Heute letzten Jahres",
    "weekstart"                        => "1",
    "yesterday"                        => "Gestern",
];
