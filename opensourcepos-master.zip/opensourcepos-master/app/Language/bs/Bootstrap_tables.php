<?php

return [
    "all"                  => "Sve",
    "columns"              => "Kolone",
    "hide_show_pagination" => "Sakrij / prikaži paginaciju",
    "loading"              => "Učitavanje sačekajte...",
    "page_from_to"         => "Prikazivanje {0} do {1} od {2} redova",
    "refresh"              => "Osvježi",
    "rows_per_page"        => "{0} redova po stranici",
    "toggle"               => "Promijeni prikaz",
];
