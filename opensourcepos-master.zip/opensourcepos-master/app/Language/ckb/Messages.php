<?php

return [
    'first_name' => "ناوی یەکەم",
    'last_name' => "ناوی خێزانی",
    'message' => "نامە",
    'message_placeholder' => "نامەکەت لێرە...",
    'message_required' => "نامە پێویستە",
    'multiple_phones' => "(لە حاڵەتی چەندین وەرگر ژمارەی مۆبایل داخڵ بکە کە بە کۆما جیاکراونەتەوە)",
    'phone' => "ژمارەی تەلەفوون",
    'phone_number_required' => "ژمارەی تەلەفوون پێویستە",
    'phone_placeholder' => "ژمارەی تەلەفوون(کان) لێرە...",
    'sms_send' => "کورتە نامە بنێرە",
    'successfully_sent' => "نامەکە نێردرا بەسەرکەوتووی بۆ: ",
    'unsuccessfully_sent' => "نامەیەک بە سەرکەوتوویی نێردراوە بۆ: ",
];
