ALTER TABLE `ospos_attribute_values` CHANGE `attribute_datetime` `attribute_date` DATE DEFAULT NULL;
