INSERT INTO
`ospos_app_config` (`key`,`value`)
VALUES
('currency_code','');
